export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });
    const body = req.body || {};
    const { messages } = body;
    if (!Array.isArray(messages)) {
      return res.status(400).json({ error: 'messages[] required' });
    }

    const system = {
      role: 'system',
      content: `You are Malcolm, the 20AI assistant. Be friendly, clear, and practical.
Greet users by name if provided. Give detailed, step-by-step help for small
businesses: strategy, marketing, pricing, copywriting, SOPs, blog posts,
product descriptions, social captions, checklists, and lightweight analysis.
Ask 1–2 clarifying questions when needed, then produce the best possible answer or draft.`
    };

    const payload = {
      model: 'gpt-4o-mini',
      messages: [system, ...messages],
      temperature: 0.7
    };

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!r.ok) {
      const errText = await r.text();
      return res.status(r.status).json({ error: errText });
    }

    const data = await r.json();
    const reply = data?.choices?.[0]?.message?.content || '';
    return res.status(200).json({ reply });
  } catch (e) {
    return res.status(500).json({ error: e?.message || 'Server error' });
  }
}
